# Flutter Furniture App

A new Flutter project.

## Screenshots
<p align="center">
  <img src="https://raw.github.com/vcjpierre/flutter-furniture-app/master/assets/screenshots/Screenshot_1544919770.png" height="600em"/> 
  <img src="https://raw.github.com/vcjpierre/flutter-furniture-app/master/assets/screenshots/Screenshot_1545165162.png" height="600em"/> 
  <img src="https://raw.github.com/vcjpierre/flutter-furniture-app/master/assets/screenshots/Screenshot_1544919773.png" height="600em"/> 
</p>

## Getting Started

This project is a starting point for a Flutter application.

A few resources to get you started if this is your first Flutter project:

- [Lab: Write your first Flutter app](https://flutter.io/docs/get-started/codelab)
- [Cookbook: Useful Flutter samples](https://flutter.io/docs/cookbook)

For help getting started with Flutter, view our 
[online documentation](https://flutter.io/docs), which offers tutorials, 
samples, guidance on mobile development, and a full API reference.
